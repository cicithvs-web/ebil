const settings = {
  token: '', // token dari @BotFather
    
  ownerId: idtele, // user id
  dev: 'nama', // wajib username tele
  
  dana: '-', // nomer dana
  namaDana: '-', // nama
    
  chUsn: '@namach', // ch tele
  
  exPGroupId: "-1003972070632", // id group
  exGroupId: "-1003972070632", // id group
    
  hostname: "", // hostname vps
  cfApiToken: "", // api token cloudflare
  cfZoneId: "", // zone id domain cf
    
  apiDigitalOcean: "", // apikey do
    
  apiDigitalOcean2: "-", // apikey do 2
  
  apiDigitalOcean3: "-", // apikey do 3
  
  pp: 'https://files.catbox.moe/0aw77a.jpg', // file catbox foto
  ppVid: 'https://files.catbox.moe/lvxmc6.mp4', // file catbox video
  panel: 'https://files.catbox.moe/a7ljii.jpeg', // foto panel

  qris: 'https://files.catbox.moe/yydnd9.jpg', // qris

  domain: '', // domain public
  plta: '', // ptla panel
  pltc: '', // ptlc panel
    
  domainPriv: '-', // domain private
  pltaPriv: '-', // apikey ptla
  pltcPriv: '-', // apikey ptlc
    
    // PANEL SERVER 2
  domainV2: '', // domain v2
  pltaV2: '', // plta v2
  pltcV2: '', // ptlc v2
    
    // PANEL SERVER 3
  domainV3: '-', // domain v3 
  pltaV3: '-', // ptla v3
  pltcV3: '-', // ptlc v3
    
    // PANEL SERVER 4
  domainV4: '-', // domain v4
  pltaV4: '-', // ptla v4
  pltcV4: '-', // ptlc v4
    
    // PANEL SERVER 5
  domainV5: '-', // domain v5
  pltaV5: '-', // ptla v5
  pltcV5: '-', // ptlc v5
  
  loc: '1', // location id
  eggs: '15' // egg id
};

module.exports = settings;